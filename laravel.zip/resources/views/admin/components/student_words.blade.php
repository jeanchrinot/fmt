<p class="text-muted"><strong>Nom et prénoms :</strong> {{ $details->user->surname }} {{ $details->user->name }}</p>
<p class="text-muted"><strong>Département :</strong> {{ $details->user->department }}</p>
<p class="text-muted"><strong>Mots :</strong></p>
<p class="small">{{ $details->words }}</p>