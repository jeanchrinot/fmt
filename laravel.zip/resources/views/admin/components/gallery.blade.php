<p class="text-muted"><strong>Titre:</strong> {{ $details->title }}</p>
<div>
	<img src="{{ getImage($details->image) }}" style="max-width: 100%;">
</div>