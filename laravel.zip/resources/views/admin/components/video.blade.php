<p class="text-muted"><strong>Titre:</strong> {{ $details->title }}</p>
<div>
	<iframe width="100%" height="315" src="{{ $details->video }}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>