<?php $__env->startSection('title','Ajouter une catégorie de galerie'); ?>

<?php $__env->startSection('main'); ?>
<!--Content right-->
<main class="col-sm-9 mx-auto col-xs-12 content pt-3 pl-0">
  <h5 class="mb-0" ><strong>Vous pouvez ajouter  ici des catégories</strong></h5>
  <span class="text-secondary">Galerie <i class="fa fa-angle-right"></i>Catégories</span>

<?php
  if(isset($category)){
  $update = 1;
} 
else{
  $update = 0;
}
?>

  <!--modif membre bureau-->
  <div class="box-modif-student_word mt-3 mb-4 p-3 button-container bg-white border shadow-sm">
    <form class=" needs-validation p-2" novalidate id="new-member" action="<?php echo e(($update==1) ? url('admin/gallerycategory/update/'.$category->id) :  url('admin/gallerycategory/store')); ?>" method="post">
      <?php echo e(csrf_field()); ?>


      <?php if(isset($category)): ?>
        <?php echo method_field('PATCH'); ?>
      <?php endif; ?>

          <?php if(\Session::has('success')): ?>
              <div class="alert alert-success">
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>

          <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                                <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
             <?php endif; ?>

      <div class="form-row">
        <div class="col-md-4 mb-2">
          <label for="nom">Nom de la catégorie <span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="nom" placeholder="Ex: covid-19" name="name" value="<?php echo e(old('name') ?? ($category->name ?? '')); ?>" required>
          <div class="invalid-feedback">
            Veuillez entrer le nom 
          </div>
        </div>
      </div>
  <div class="form-row">
   <button class="btn btn-primary my-2" type="submit">Enregistrer</button>
 </div>
</form>
</div><!--End modif student word-->

</main>
<!--Main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/admin/gallerycategory_form.blade.php ENDPATH**/ ?>