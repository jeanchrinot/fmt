<div class="avatar avatar--details">
	<div class="avatar__left">
		<img src="<?php echo e(getUserImage($details->image)); ?>" alt="" class="rounded-circle" style="margin-top: 0;" />
	</div>
	<div class="avatar__right">
		<p class="text-muted"><strong>Nom:</strong> <?php echo e($details->surname); ?> <strong>Prénoms:</strong> <?php echo e($details->name); ?></p>
        <p class="text-muted"><strong>Type:</strong> <?php echo e(getMemberType($details->type)); ?></p>
	</div>      
</div>
<p class="text-muted"><strong>Email:</strong> <?php echo e($details->email); ?></p>
<p class="text-muted"><strong>Téléphone:</strong> <?php echo e($details->phone); ?></p>
<p class="text-muted"><strong>Ville:</strong> <?php echo e(province($details->province)); ?></p>
<p class="text-muted"><strong>Date de naissance:</strong> <?php echo e(date_format(date_create($details->birthday),"d/m/Y")); ?></p>
<p class="text-muted"><strong>Département:</strong> <?php echo e($details->department); ?></p>
<p class="text-muted"><strong>Genre:</strong> <?php echo e(gender($details->gender)); ?></p><?php /**PATH E:\malagasy\laravel\resources\views/admin/components/users.blade.php ENDPATH**/ ?>