<?php $__env->startSection('title','Galerie Photos'); ?>

<?php $__env->startSection('main'); ?>
<section class="md-section">
	<div class="container p-4">
		<div class="row wow slideInRight">
			<div class="col-7 section-title">
				<h1 class="text-muted section-title--styled">Galerie Photos</h1>
			</div>
			<div class="col-4 float-right">
				<div class="recherche">
					<label for="search">Filtrer par :</label>
					<?php if($categories): ?>
					<select id="category" class="form-control">
						<option value="">Catégorie</option>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($cat->slug); ?>" <?php echo e((request()->cat==$cat->slug) ? 'selected' : ''); ?> ><?php echo e($cat->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-9">

				<div class="row gallery" id="gallery">
					<?php if($galleries): ?>
					<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-6 col-sm-4 col-lg-3">
						<a href="<?php echo e(getImage($gallery->image)); ?>"><img class=" wow bounceOut image-item card-img" src="<?php echo e(getImage($gallery->image)); ?>"></a>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<?php endif; ?>
					
				</div>
				
				<?php if($galleries): ?><div class="pagination-div"><?php echo e($galleries->appends(request()->input())->links()); ?></div><?php endif; ?>

			</div>


			<aside class="col-md-3 mt-5 mt-md-1 wow slideInRight">
				<div class="sidebar-gallery">
					<div class="gallery-title p-2">Galerie Photos</div>
					<div class="block-content">
						<ul id="recently-viewed-items">
							<li class="year">&gt;<a href="?year=2020">2020</a></li>
							<li class="year">&gt;<a href="?year=2019">2019</a></li>
							<li class="year">&gt;<a href="?year=2018">2018</a></li>
							<li class="year">&gt;<a href="?year=2017">2017</a></li>
							<li class="year">&gt;<a href="?year=2016">2016</a></li>
							<li class="year">&gt;<a href="?year=2015">2015</a></li>
						</ul>
					</div>
				</div>

				<div class="sidebar-video bg-white p-1">
					<div class="videoWrapper my-3">
						<iframe class="w-100" src="https://www.youtube.com/embed/wIOFD9R8y_Q" frameborder="0" allowfullscreen></iframe>
						<h3 class="my-3"><a href="<?php echo e(route('page.video')); ?>" class="btn btn-lg btn-common section-btn section-btn--green">Autres vidéos <i class="fa fa-long-arrow-right"></i></a></h3>
					</div>
				</div>
			</aside>
		</div>
	</div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/gallery.blade.php ENDPATH**/ ?>