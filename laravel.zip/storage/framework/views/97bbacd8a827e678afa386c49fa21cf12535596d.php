<?php $__env->startSection('title','Ajouter une activité'); ?>

<?php $__env->startSection('main'); ?>
<!--Content right-->
<main class="col-sm-9 mx-auto col-xs-12 content pt-3 pl-0">
  <h5 class="mb-0" ><strong>Vous pouvez ajouter  ici les activités</strong></h5>
  <span class="text-secondary">Actualités <i class="fa fa-angle-right"></i>Ajouter</span>

<?php
  if(isset($activity)){
  $update = 1;
} 
else{
  $update = 0;
}
?>

  <!--modif membre bureau-->
  <div class="box-modif-student_word mt-3 mb-4 p-3 button-container bg-white border shadow-sm">
    <form class=" needs-validation p-2" novalidate id="new-member" action="<?php echo e(($update==1) ? url('admin/activity/update/'.$activity->id) :  url('admin/activity/store')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>


      <?php if(isset($activity)): ?>
        <?php echo method_field('PATCH'); ?>
      <?php endif; ?>

      

      <?php 

      if(old('status')){
        $status = old('status');
      }
      elseif(isset($activity->status)){
        $status = $activity->status;
      }
      else{
        $status = '1';
      }

      ?> 

          <?php if(\Session::has('success')): ?>
              <div class="alert alert-success">
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>

          <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                                <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
             <?php endif; ?>

      <div class="form-row">
        <div class="col-md-6 mb-2">
          <label for="nom">Titre <span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="name" placeholder="Titre" name="name" value="<?php echo e(old('name') ?? ($activity->name ?? '')); ?>" required>
          <div class="invalid-feedback">
            Veuillez entrer le titre 
          </div>
        </div>
        <div class="col-md-6 mb-2">
          <label for="activity_date">Date de l'activité <span class="text-danger">*</span></label>
          <div class="input-group">   
            <input type="datetime-local" class="form-control" id="activity_date" aria-describedby="inputGroupPrepend" name="activity_date" value="<?php echo e(old('activity_date') ?? (formatDateTimeLocal($activity->activity_date ?? '') ?? '')); ?>" required>
            <div class="invalid-feedback">
              Entrez la date de l'activité
            </div>
          </div>
        </div>
        <div class="col-md-12 mb-2">
          <label for="description-slide-1">Détails <span class="text-danger">*</span></label>
          <textarea rows="5" type="text" class="form-control" name="details" id="details" required><?php echo e(old('details') ?? ($activity->details ?? '')); ?></textarea>
          <div class="invalid-feedback">
            Veuillez remplir le détails
          </div>
        </div>
      </div>

      <div class="form-row">
        <div class="col-md-4 mb-2">
          <label for="featured">Affiché ? <span class="text-danger">*</span></label>
          <select class="form-control" id="featured" name="featured" required>
            <option value="1" <?php echo e(($status==1) ? 'selected="selected"' : ''); ?>>Oui</option>
            <option value="0" <?php echo e(($status==0) ? 'selected="selected"' : ''); ?>>Non</option>
          </select>
          <div class="invalid-feedback">
            Veuillez choisir le statut
          </div>
        </div>
        <div class="col-md-6 mb-2">
          <div class="form-group">
          <label for="profession">Image <span class="text-danger">*</span></label>
          <input type="file" class="form-control" id="image" name="image" <?php echo e(($update==1) ? '':'required'); ?>>
           <div class="invalid-feedback">
            Veuillez choisir une image
          </div>
        </div>
        </div>
      </div>

      <div class="form-row">
       <div class="col-md-4 mb-2">
        
      </div>
    </div>
  <div class="form-row">
   <button class="btn btn-primary my-2" type="submit">Enregistrer</button>
  </div>
</form>
</div><!--End modif student word-->

</main>
<!--Main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/admin/activity_form.blade.php ENDPATH**/ ?>