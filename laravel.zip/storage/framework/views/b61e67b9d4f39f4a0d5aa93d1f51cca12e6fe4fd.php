<!DOCTYPE html>
<html>
<head>
	<title>TEST</title>
</head>
<body>
	<h1>Welcome to this brand new project!</h1>

</body>
</html><?php /**PATH E:\malagasy\laravel\resources\views/test/index.blade.php ENDPATH**/ ?>