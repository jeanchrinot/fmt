<?php $__env->startSection('title','Modifier A propos'); ?>

<?php $__env->startSection('main'); ?>
<!--Content right-->
<main class="col-sm-9 mx-auto col-xs-12 content pt-3 pl-0">
  <h5 class="mb-0" ><strong>Modifier A propos</strong></h5>
  <span class="text-secondary">Pages <i class="fa fa-angle-right"></i>A propos</span>

  <!--modif membre bureau-->
  <div class="box-modif-student_word mt-3 mb-4 p-3 button-container bg-white border shadow-sm">
    <form class=" needs-validation p-2" novalidate id="new-member" action="<?php echo e(route('page.item.update',['item'=>'about','id'=>$about->id])); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>


        <?php echo method_field('PATCH'); ?>

          <?php if(\Session::has('success')): ?>
              <div class="alert alert-success">
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>

          <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                                <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
             <?php endif; ?>

      <div class="form-row">
        <div class="col-md-6 col-md-12">
          <label for="description-slide-1">A propos</label>
          <textarea rows="5" type="text" class="form-control" name="about" id="about" required><?php echo e(old('about') ?? ($about->about ?? '')); ?></textarea>
          <div class="invalid-feedback">
            Veuillez remplir l'a propos
          </div>
        </div>
        <div class="col-md-6 col-md-12">
          <label for="description-slide-1">Mot du président</label>
          <textarea rows="5" type="text" class="form-control" name="words_of_president" id="words_of_president" required><?php echo e(old('words_of_president') ?? ($about->words_of_president ?? '')); ?></textarea>
          <div class="invalid-feedback">
            Veuillez remplir le mot du président
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="col-md-6 col-md-12">
          <label for="description-slide-1">Mission</label>
          <textarea rows="5" type="text" class="form-control" name="mission" id="mission"><?php echo e(old('mission') ?? ($about->mission ?? '')); ?></textarea>
          <div class="invalid-feedback">
            Veuillez remplir la mission
          </div>
        </div>
        <div class="col-md-6 col-md-12">
          <label for="description-slide-1">Vision</label>
          <textarea rows="5" type="text" class="form-control" name="vision" id="vision"><?php echo e(old('vision') ?? ($about->vision ?? '')); ?></textarea>
          <div class="invalid-feedback">
            Veuillez remplir la vision
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="col-md-6 col-md-12">
          <label for="description-slide-1">Image 1</label>
          <input type="file" class="form-control" name="image" id="image1">
          <div class="invalid-feedback">
            Veuillez choisir une image
          </div>
        </div>
        <div class="col-md-6 col-md-12">
          <label for="description-slide-1">Image 2</label>
          <input type="file" class="form-control" name="image2" id="image2">
          <div class="invalid-feedback">
            Veuillez choisir une image
          </div>
        </div>
      </div>
  <div class="form-row">
   <button class="btn btn-primary my-2" type="submit">Enregistrer</button>
 </div>
</form>
</div><!--End modif student word-->

</main>
<!--Main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/admin/about_form.blade.php ENDPATH**/ ?>