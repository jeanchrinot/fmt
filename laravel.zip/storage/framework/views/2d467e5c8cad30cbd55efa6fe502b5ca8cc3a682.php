<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="description" content="" >
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!--Meta Responsive tag-->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--Favicon Icon-->
    <!--<link rel="icon" href="favicon.ico" type="image/x-icon">-->
    <!--Bootstrap CSS-->
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <!--Custom style.css-->
    <link rel="stylesheet" href="/assets/css/quicksand.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <!--Font Awesome-->
    <link rel="stylesheet" href="/assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="/assets/css/fontawesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--Animate CSS-->
    <link rel="stylesheet" href="/assets/css/animate.min.css">
    <!--Nice select -->
    <link rel="stylesheet" href="/assets/css/nice-select.css">

    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>


 
<body>


    <!--Page loader-->
    <div class="loader-wrapper">
        <div class="loader-circle">
            <div class="loader-wave"></div>
        </div>
    </div>
    <!--Page loader-->
    
    <!--Page Wrapper-->

    <div class="container-fluid">

        <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row main-content">

        <?php echo $__env->yieldContent('main'); ?>

    </div><!--Content right-->
     
    </div> <!--Page Wrapper-->

    <?php echo $__env->make('admin.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<?php /**PATH E:\malagasy\laravel\resources\views/admin/layouts/admin.blade.php ENDPATH**/ ?>