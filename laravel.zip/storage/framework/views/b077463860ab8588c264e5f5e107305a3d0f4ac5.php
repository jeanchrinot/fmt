<p class="text-muted"><strong>Nom et prénoms :</strong> <?php echo e($details->user->surname); ?> <?php echo e($details->user->name); ?></p>
<p class="text-muted"><strong>Département :</strong> <?php echo e($details->user->department); ?></p>
<p class="text-muted"><strong>Mots :</strong></p>
<p class="small"><?php echo e($details->words); ?></p><?php /**PATH E:\malagasy\laravel\resources\views/admin/components/student_words.blade.php ENDPATH**/ ?>