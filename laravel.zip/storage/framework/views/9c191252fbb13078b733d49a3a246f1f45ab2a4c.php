<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
	<title>Login | Malagasy eto Torkia</title>
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/fonts/fontawesome/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/style.css">
</head>
<body id="login-page" class="bg-light">

	<header class="container-fluid">
		<div class="row bg-info p-1">
			<div class="logo">
				<img src="../assets/img/logo.jpg"> 
			</div>
			<a class="navbar-brand" href="../public/index.php">malagasy eto torkia</a>
		</div>
	</header>

	<div class="container p-3">
		<style type="text/css">
			
		</style>
		<form action="<?php echo e(url('admin/auth')); ?>" class="login-form shadow" method="post">
			<?php echo e(csrf_field()); ?>

			<h4>Administrateur</h4>
			<div class="form-group">
				<label>Pseudo ou adresse email : </label>
				<input type="text" name="email" class="form-control" value="<?php echo e(old('email')); ?>" autofocus>
			</div>
			<div class="form-group">
				<label>Mot de passe : </label>
				<input type="password" name="password" class="form-control">
			</div>
			<p><a href="forgot-password.php">Mot de passe oublie?</a></p>
			<p><input type="checkbox" name="remember-me" checked>&nbsp;&nbsp;Souvenir</p>
			<button class="btn btn-info w-100" type="submit">Se connecter</button>


			<?php if(isset($errorMessage)): ?>

				<span class="error"><?php echo e($errorMessage ?? ''); ?></span>

			<?php endif; ?>

			 <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                                <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
             <?php endif; ?>
		</form>

	</div>
	
</body>
</html><?php /**PATH E:\malagasy\laravel\resources\views//admin/login.blade.php ENDPATH**/ ?>