<p class="text-muted"><strong>Titre:</strong> <?php echo e($details->title); ?></p>
<div>
	<iframe width="100%" height="315" src="<?php echo e($details->video); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div><?php /**PATH E:\malagasy\laravel\resources\views/admin/components/video.blade.php ENDPATH**/ ?>