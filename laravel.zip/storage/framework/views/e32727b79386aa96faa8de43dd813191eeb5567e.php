<footer class="md-section bg-dark">

  <div class="container">
    <div class="row">
      <div class="col-lg-4 wow slideInLeft">

        <!-- sec-title -->
        <div class="sec-title">
          <h2 class="sec-title__title">SUIVEZ-NOUS</h2><span class="sec-title__divider"></span>
        </div><!-- End / sec-title -->

        <?php if($socials): ?>
        <ul class="socials">
              <li class="socials__item"><a href="<?php echo e($socials->facebook); ?>" target="_blank"><i class="fa fa-facebook"></i> Facebook</a></li>
              <li class="socials__item"><a href="<?php echo e($socials->twitter); ?>" target="_blank"><i class="fa fa-twitter"></i> Twitter</a></li>
              <li class="socials__item"><a href="<?php echo e($socials->youtube); ?>" target="_blank"><i class="fa fa-youtube"></i> Youtube</a></li>
              <li class="socials__item"><a href="<?php echo e($socials->instagram); ?>" target="_blank"><i class="fa fa-instagram"></i> Instagram</a></li>
        </ul>
        <?php endif; ?>
        
      </div>


      <div class="col-lg-4 wow bounce">

        <!-- sec-title -->
        <div class="sec-title">
          <h2 class="sec-title__title">Galerie Images</h2><span class="sec-title__divider"></span>
        </div><!-- End / sec-title -->

        

        <!-- widget-gallery -->

        <div class="row widget-gallery footer-gallery">
          <?php if($footer_galleries): ?>
          <?php $__currentLoopData = $footer_galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="widget-gallery__item">
            <a title="<?php echo e($gallery->title); ?>" href="<?php echo e(getImage($gallery->image)); ?>"><img src="<?php echo e(getImage($gallery->image)); ?>" alt="<?php echo e($gallery->title); ?>"/></a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </div><!-- End /  widget-gallery -->
        

      </div>


      <div class="col-lg-4 pb-5 footer-link wow slideInRight">
        <!-- sec-title -->
        <div class="sec-title">
          <h2 class="sec-title__title">Lien rapide :</h2><span class="sec-title__divider"></span>
        </div><!-- End / sec-title -->

        <p><a class="quick-link" href="/#about"> <i class="fa fa-angle-right"></i> A propos de nous</a></p>
        <p>
          <a class="quick-link" href="<?php echo e(route('page.gallery')); ?>"> <i class="fa fa-angle-right"></i> Galerie Image</a>
        </p>
        <p>
          <a class="quick-link" href="<?php echo e(route('page.video')); ?>"> <i class="fa fa-angle-right"></i> Galerie Vidéo</a>
        </p>
        <p>
          <a class="quick-link" href="<?php echo e(route('page.actuality')); ?>"><i class="fa fa-angle-right"></i>
           Actualités</a></p>
        <p><a class="quick-link" href="<?php echo e(route('page.activity')); ?>"> <i class="fa fa-angle-right"></i> Activités</a></p>
        <p><a class="quick-link" href="/#contact"><i class="fa fa-angle-right"></i> Contacts</a></p>

      </div>

    </div>

  </div>

</footer>
<?php /**PATH E:\malagasy\laravel\resources\views/includes/footer.blade.php ENDPATH**/ ?>