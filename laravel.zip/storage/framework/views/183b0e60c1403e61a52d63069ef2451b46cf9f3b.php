<p class="text-muted"><strong>Nom et prenom :</strong> <?php echo e($message->name); ?> <?php echo e($message->surname); ?></p>
<p class="text-muted"><strong>Email:</strong> <?php echo e($message->email); ?></p>
<p class="text-muted"><strong>Téléphone:</strong> <?php echo e($message->phone); ?></p>
<p class="text-muted"><strong>Sujet :</strong><?php echo e($message->subject); ?></p>
<p class="text-muted"><strong>Message :</strong></p>
<p class="small"><?php echo e($message->message); ?></p><?php /**PATH E:\malagasy\laravel\resources\views/admin/components/message.blade.php ENDPATH**/ ?>