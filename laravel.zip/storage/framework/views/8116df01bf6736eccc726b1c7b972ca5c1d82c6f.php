<?php $__env->startSection('title','Ajouter des sliders'); ?>

<?php $__env->startSection('main'); ?>
<main class="col-sm-9 col-xs-12 content pt-3 pl-0">
  <h5 class="mb-0" ><strong>Vous pouvez modifiez ici les pages</strong></h5>
  <span class="text-secondary">Pages <i class="fa fa-angle-right"></i> Edit slider</span>

  <!--<div class="row">
    <div class="col-12 mb-3">
      <button class="btn btn-info float-right" id="addSliderField">Ajouter un nouveau champ</button>
    </div>
  </div>-->

<?php
  if(isset($slider)){
  $update = 1;
} 
else{
  $update = 0;
}

if(old('featured')){
  $featured = old('featured');
}
elseif(isset($slider->featured)){
  $featured = $slider->featured;
}
else{
  $featured = '1';
}

?>

  <div class="box-modif-slider mt-3 mb-4 p-3 button-container bg-white border shadow-sm">

    <form class="needs-validation" novalidate id="form-slide" action="<?php echo e(($update==1) ? route('page.item.update',['item'=>'slider','id'=>$slider->id]) : route('page.item.store',['item'=>'slider'])); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>

      <?php if($update==1): ?>
        <?php echo method_field('PATCH'); ?>
      <?php endif; ?>

      <?php if(\Session::has('success')): ?>
              <div class="alert alert-success">
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>

          <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                                <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
             <?php endif; ?>

      <div class="form-row" id="last-slide">
        <div class="col-sm-6">
          <h4 class="text-muted text-capitalize">Ajouter ou modifier un slide</h4>
        </div>
        <div class="col-sm-6">
          <button class="btn btn-secondary float-right" type="submit">Enregistrer</button>
        </div>
      </div>
      <div class="form-row">
        <div class="col-sm-6 col-md-4">
          <label for="label-slide-1">Label de l'image</label>
          <input type="text" class="form-control" name="name" id="label-slide-1" value="<?php echo e(old('name') ?? ($slider->name ?? '')); ?>" required>
          <div class="invalid-feedback">
            Veuillez entrer un label d'image
          </div>
        </div>
        <div class="col-sm-12 col-md-4">
          <label for="image-slide-1">Image:</label>
          <input type="file" class="form-control" name="image" id="image-slide-1" <?php echo e(($update==1) ? '' : 'required'); ?>>
          <div class="invalid-feedback">
            Veuillez choisir un image
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="col-sm-6 col-md-4">
          <label for="image-slide-1">Statut:</label>
          <select class="form-control" id="featured" name="featured" required>
            <option value="1" <?php echo e(($featured=='1') ? 'selected="selected"' : ''); ?>>Actif</option>
            <option value="0" <?php echo e(($featured=='0') ? 'selected="selected"' : ''); ?>>Passif</option>
          </select>
          <div class="invalid-feedback">
            Veuillez choisir un statut
          </div>
        </div>
        <div class="col-sm-6 col-md-4">
          <label for="description-slide-1">Description du slide</label>
          <textarea type="text" class="form-control" name="details" id="description-slide-1"><?php echo e(old('details') ?? ($slider->details ?? '')); ?></textarea>
          <div class="invalid-feedback">
            Veuillez entrer une description
          </div>
        </div>
        <div class="col-12">
          <div class="image" style="margin-top: 20px;">
            <?php if(isset($slider->image)): ?><img src="<?php echo e(getImage($slider->image)); ?>" style="max-width: 100%;"><?php endif; ?>
          </div>
        </div>
      </div>


     <!-- <div class="form-row">
        <div class="col-sm-6 col-md-4">
          <label for="label-slide-2">Label du slide 2</label>
          <input type="text" class="form-control" name="label-slide-2" id="label-slide-2" required>
          <div class="invalid-feedback">
            Veuillez choisir le label d'image 2
          </div>
        </div>
        <div class="col-sm-6 col-md-4">
          <label for="image-slide-2">Image 2:</label>
          <input type="file" class="form-control" name="image-slide-2" id="image-slide-2" required>
          <div class="invalid-feedback">
            Veuillez choisir l'image
          </div>
        </div>
        <div class="col-sm-6 col-md-4">
          <label for="description-slide-2" class="">Description du slide 2</label>
          <textarea type="text" class="form-control" name="description-slide-2" id="description-slide-2" required></textarea>
          <div class="invalid-feedback">
            Veuillez choisir la description d'image 2
          </div>
        </div>  
      </div>

      <div class="form-row">
        <div class="col-sm-6 col-md-4">
          <label for="label-slide-3">Label du slide 3</label>
          <input type="text" class="form-control" name="label-slide-3" id="label-slide-3" required>
          <div class="invalid-feedback">
            Veuillez choisir le label d'image 3
          </div>
        </div>
        <div class="col-sm-6 col-md-4">
          <label for="image-slide-3">Image 3:</label>
          <input type="file" class="form-control" name="image-slide-3" id="image-slide-3" required>
          <div class="invalid-feedback">
            Veuillez choisir l'image
          </div>
        </div>
        <div class="col-sm-6 col-md-4">
          <label for="description-slide-3" class="">Description du slide 3</label>
          <textarea type="text" class="form-control" name="description-slide-3" id="description-slide-3" required></textarea>
          <div class="invalid-feedback">
            Veuillez choisir la description d'image 3
          </div>
        </div>  
      </div>->
    </form>

  </div><!--end-box-modif-slider-->
</main>
<!--Main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/admin/slider_form.blade.php ENDPATH**/ ?>