        <!-- Page JavaScript Files-->
        <script src="/admin/assets/js/jquery.min.js"></script>
        <script src="/admin/assets/js/jquery-1.12.4.min.js"></script>
        <!--Popper JS-->
        <script src="/admin/assets/js/popper.min.js"></script>
        <!--Bootstrap-->
        <script src="/admin/assets/js/bootstrap.min.js"></script>
        <script src="/admin/assets/js/jquery.nice-select.min.js"></script>

        <!--Custom Js Script-->
        <script src="/admin/assets/js/custom.js"></script>
        <script type="text/javascript" src="/js/app.js"></script>
        <!--Custom Js Script--><?php /**PATH E:\malagasy\laravel\resources\views/admin/includes/scripts.blade.php ENDPATH**/ ?>