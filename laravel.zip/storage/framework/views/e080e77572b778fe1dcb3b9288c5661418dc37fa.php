<?php $__env->startSection('title','Page d\'accueil'); ?>
<?php $__env->startSection('main'); ?>


<!--slider-->
<section class="container-fluid wow fadeIn">
  <!-- Slider main container -->
  <div class="swiper-container index">
    <div class="swiper-wrapper">
      <?php if($sliders): ?>
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="swiper-slide">
            <img src="<?php echo e(getImage($slider->image)); ?>" class="w-100">
            <div class="carousel-caption">
                <p><?php echo e($slider->name); ?></p>
                <h2><?php echo e($slider->details); ?></h2>
                <!-- <a class="btn btn-lg btn-common"><i aria-hidden="true" class="fa fa-arrow-circle-right"></i> Get Started</a> -->
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>

    <div class="swiper-pagination swiper-pagination-index"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <div class="swiper-scrollbar"></div>
  </div>

  <!-- presentation-->
  <div class="presetantion">
    <div class="container-fluid">
      <div class="row">

        <h3 class="title-slider wow slideInLeft">Tonga soa ato amin’ny pejy « fiombonan’ny malagasy eto torkia ».</h3>

      </div>
    </div>
  </div><!-- end / presentation -->
</section>
<!--end slider-->

<!--actualite-->
<?php if($news): ?>
<section class=" p-5 bg-lighter">
  <div class="container">
  <div class="section-title text-center">
    <h2 class="mt-0">Dernières <span class="red">Nouvelles</span></h2>
    <span class="bordered-icon"><i class="fa fa-newspaper-o"></i></span>
  </div>
  <div class="section-content">
  <div class="row">
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
      $date = dateToFrench($new->created_at,"j F");
      $dates = explode(" ",$date);
      $day = $dates[0];
      $month = $dates[1];
    ?>
    <div class="col-xs-12 col-sm-6 col-md-4 wow fadeInLeft">
        <article class="post clearfix mb-sm-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="<?php echo e(getImage($new->image)); ?>" alt="" class="img-responsive img-fullwidth"> 
                    <div class="thumb-overlay"></div>
                  </div>
                </div>
                <div class="entry-content p-20 pr-10 bg-white">
                  <div class="entry-meta media mt-0 no-bg no-border">
                    <div class="entry-date media-left text-center flip bg-theme-colored">
                      <ul>
                        <li class="font-16 text-white font-weight-600 border-bottom"><?php echo e($day); ?></li>
                        <li class="font-12 text-white text-uppercase"><?php echo e(substr($month,0,3)); ?></li>
                      </ul>
                    </div>
                    <div class="media-body pl-15">
                      <div class="event-content pull-left flip">
                        <h4 class="entry-title text-white text-uppercase m-0"><a href="/actualites/<?php echo e($new->slug); ?>"><?php echo e($new->title); ?></a></h4>                      
                      </div>
                    </div>
                  </div>
                  <p class="mt-10 fw-300"><?php echo e(subString($new->details,124)); ?></p>
                  <a href="/actualites/<?php echo e($new->slug); ?>" class="btn-read-more">Voir plus <i class="fa fa-arrow-circle-right"></i></a>
                  <div class="clearfix"></div>
                </div>
          </article>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="text-center mt-3">
    <a href="/actualites/" class="btn btn-lg btn-common section-btn"><i aria-hidden="true" class="fa fa-long-arrow-right"></i> Voir tout</a>
  </div>
  </div>
  </div>
</section>

<!-- <section  class="container-fluid p-5 wow fadeIn" id="slide-activity">
  <div class="slide-news container bg-white">

    <div class="slide-activity wow backInDown">
  
      <div class="card">
        <img class="card-img-top" src="<?php echo e(getImage($new->image)); ?>" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($new->title); ?></h5>
          <p class="card-text small "><?php echo e($new->details); ?></p>
          <a href="/news/<?php echo e($new->slug); ?>" class="btn btn-primary">Voir plus</a>
        </div>
      </div>
      
    </div>
  </div>
</section> -->
<?php endif; ?>
<!--end-actualite-->

<!--about-->
<section id="about" class="p-md-3" >

  <div class="container ">

    <div class="row">
      <div class="col-md-6 wow SlideInLeft">
        <div class="section-title text-center">
          <h2 class="wow slideInRight">A Propos</h2>
          <span class="bordered-icon"><i class="fa fa-institution"></i></span>
        </div>
        <p class="wow slideInLeft fw-300"><?php echo e($about->about); ?></p>
      </div>

      <div class="col-md-6 wow slideInRight">
        <div class="president-box">

          <div class="img-president">
            <img src="<?php echo e(getImage($about->image)); ?>">
            <p class="president-word fw-300" style="display: none;">
              <?php echo e($about->words_of_president); ?>

            </p>
          </div>

          <!-- quote-->
          <blockquote class="quote about-quote">
            <p class="quote-02__text">
              <?php echo e($about->words_of_president); ?>

            </p>
            <!-- president -->
            <div style="float: right;">
              <div class="president__info">
                <h5 class="president__name">Mr Zafera eliot</h5>
                <p>Président</p>
              </div>
            </div><!-- end / president -->

          </blockquote><!-- end / quote -->

        </div><!-- end / about -->

      </div>
    </div>
  </div>
</section>
<!--end about-->


<!--Student-->
<section  id="student">

 <div class="section-title text-center">
  <h2 class="wow slideInRight">Mot des <span class="red">étudiants</span></h2>
  <span class="bordered-icon"><i class="fa fa-quote-left"></i></span>
</div>


<div class="container owl-carousel owl-theme wow fadeIn">

<?php $__currentLoopData = $studentwords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="item">
    <div class="student">
      <div class="student-word">
        <?php echo e($studentword->words); ?>

      </div>
      <div class="description justify-content-center">
        <span class="text-muted  my-auto"><?php echo e($studentword->user->department); ?></span>
        <img src="<?php echo e(getUserImage($studentword->user->image)); ?>" class="rounded-circle ml-3">
      </div>
    </div>
  </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</section>
<!--end student-->

<!-- Activity -->

<section id="actuality" class="p-5">
  <div class="container">
    <div class="section-title text-center">
      <h2 class="wow slideInLeft">EVENEMENTS / <span class="red">ACTIVITES</span></h2>
      <span class="bordered-icon"><i class="fa fa-calendar"></i></span>
    </div>
    <div class="section-content">
      <div class="row">
        <div class="col-md-6">
          <?php if(isset($coming_event)): ?>
          <article class="post media-post clearfix pb-0 mb-10">
            <div class="post-thumb thumb"> 
                    <img src="<?php echo e(getImage($coming_event->image)); ?>" alt="" class="img-responsive img-fullwidth">
                    <div class="count-down" id="count-down" date="<?php echo e($coming_event->activity_date); ?>">
                      <ul class="count-list">
                        <li><span class="count-value" id="count-down-day">00</span><span class="count-label">Jours</span></li>
                        <li><span class="count-value" id="count-down-hour">00</span><span class="count-label">Heures</span></li>
                        <li><span class="count-value" id="count-down-min">00</span><span class="count-label">Min</span></li>
                        <li><span class="count-value" id="count-down-sec">00</span><span class="count-label">Sec</span></li>
                      </ul>
                    </div>
                    <div class="thumb-overlay thumb-overlay--fixed"></div> 
            </div>
            <div class="post-text">
              <h4 class="mt-0"><a href="/activites/<?php echo e($coming_event->slug); ?>"><?php echo e($coming_event->name); ?></a></h4>
              <ul class="list-inline font-12 article-date">
                <li class="pr-0"><i class="fa fa-calendar"></i> <?php echo e(dateToFrench($coming_event->activity_date,"j F Y")); ?></li>
                <!-- <li class="pl-0" style="margin-left: 5px;"><i class="fa fa-map-marker"></i> New York</li> -->
              </ul>
              <p class="mb-1 font-16 fw-300"><?php echo e(subString($coming_event->details,116)); ?></p>
              <a class="text-theme-colored font-16" href="/activites/<?php echo e($coming_event->slug); ?>">Voir en entier <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </article>
          <?php endif; ?>
        </div>
        <div class="col-md-6">
          <?php if($events): ?>
          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <article class="post media-post clearfix pb-0 mb-10 post--inline">
            <div class="post-thumb">
              <a href="/activites/<?php echo e($event->slug); ?>"><img alt="" src="<?php echo e(getImage($event->image)); ?>"></a>
            </div>
            <div class="post-right post-text">
              <h4 class="mt-0"><a href="/activites/<?php echo e($event->slug); ?>"><?php echo e($event->name); ?></a></h4>
              <ul class="list-inline font-14 article-date">
                <li class="pr-0"><i class="fa fa-calendar"></i> <?php echo e(dateToFrench($event->activity_date,"j F Y")); ?></li>
                <!-- <li class="pl-0" style="margin-left: 5px;"><i class="fa fa-map-marker"></i> New York</li> -->
              </ul>
              <p class="mb-0 font-14 fw-300"><?php echo e(subString($event->details,116)); ?></p>
              <a class="text-theme-colored font-13" href="/activites/<?php echo e($event->slug); ?>">Voir plus <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </article>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </div>
      </div>
      <div class="text-center mt-3">
        <a href="/activites" class="btn btn-lg btn-common section-btn"><i aria-hidden="true" class="fa fa-long-arrow-right"></i> Voir tout</a>
      </div>
    </div>
  </div>
</section>

<!--contact-->
<section id="contact" class="contact">


 <div class="section-title wow slideInRight text-center">
  <h2 class="wow slideInLeft white">Contactez-nous</h2>
  <span class="bordered-icon"><i class="fa fa-send"></i></span>
</div>


<div class="container">

  <div class="row">

    <div class="col-lg-5 wow slideInLeft">
      <p class="contact-description">Détails du contact</p>

      <div>
        <?php if($assContact): ?>
        <?php if($assContact->phone): ?><div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-phone red"></i> Téléphone:</span>
          <p class="widget-contact__text"> <?php echo e($assContact->phone); ?></p>
        </div>
        <?php endif; ?>
        <?php if($assContact->fax): ?>
        <div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-fax red"></i> Fax:</span>
          <p class="widget-contact__text"><?php echo e($assContact->fax); ?></p>
        </div>
        <?php endif; ?>
        <?php if($assContact->email): ?>
        <div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-envelope-o red"></i> Adresse email:</span>
          <p class="widget-contact__text"><a href="mailto:consular@madagaskar.us"><?php echo e($assContact->email); ?></a></p>
        </div>
        <?php endif; ?>
        <?php if($assContact->email2): ?>
        <div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-envelope-o red"></i> Adresse email 2:</span>
          <p class="widget-contact__text"><a href="#"> <?php echo e($assContact->email2); ?></a></p>
        </div>
        <?php endif; ?>
        <?php if($assContact->address): ?>
        <div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-map-marker red"></i> Adresse:</span>
          <p class="widget-contact__text">
            <?php echo e($assContact->address); ?>

          </p>
        </div>
        <?php endif; ?>
        <?php endif; ?>

      </div>

    </div>



    <div class="col-lg-7 my-3 wow fadeIn bg-white">
      <div class="element-container">
      <form action="<?php echo e(route('contactForm')); ?>" class="needs-validation" novalidate method="post">
        <?php echo e(csrf_field()); ?>


        <div class="message_box">

          <?php if(\Session::has('success')): ?>
              <div class="alert alert-success">
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>

          <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                                <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
             <?php endif; ?>

        </div>

        <div class="form-group">
          <input type="text" class="form-control" placeholder="Nom" name="name" value="<?php echo e(old('name')); ?>" required>
          <div class="invalid-feedback">
            Veuillez entrer votre nom 
          </div>
        </div>

        <div class="form-group">
          <input type="text" class="form-control" placeholder="Prenom" name="surname" value="<?php echo e(old('surname')); ?>" required>
          <div class="invalid-feedback">
            Veuillez entrer votre prenom
          </div>
        </div>

        <div class="form-group">
          <input type="text" class="form-control" placeholder="Telephone" name="phone" value="<?php echo e(old('phone')); ?>">
          <div class="invalid-feedback">
            Veuillez entrer votre telehone
          </div>
        </div>

        <div class="form-group">
          <input type="email" class="form-control" placeholder="email" name="email" value="<?php echo e(old('email')); ?>" required>
          <div class="invalid-feedback">
            Veuillez entrer votre email
          </div>
        </div>

        <div class="form-group">
          <input type="text" class="form-control" placeholder="Sujet" name="subject" value="<?php echo e(old('subject')); ?>" required>
          <div class="invalid-feedback">
            Veuillez entrer le sujet
          </div>
        </div>

        <div class="form-group">
          <textarea class="form-control" name="message" rows="4" placeholder="Message" required><?php echo e(old('message')); ?></textarea>
          <div class="invalid-feedback">
            Veuillez entrer votre message
          </div>
        </div>


      <button class="btn btn-primary btn-round mt-3 mb-3" type="submit" style="float: right;">Envoyer</button>

    </form>
    </div>

  </div>


</div>

</div>
</section>
<!--end contact-->

<!--contact-->
<section id="consulate-contact" class="contact" >

 <div class="section-title wow slideInLeft mt-3 text-center">
  <h2 class="wow slideInLeft">Contactez <span class="red">Notre Consulat</span></h2>
  <span class="bordered-icon"><i class="fa fa-map"></i></span>
</div>


<div class="container">

  <div class="row">

    <div class="col-lg-5 wow slideInLeft">
      <p class="contact-description">Détails du Contact</p>
      <div>
        <?php if($consulatContact): ?>
        <?php if($consulatContact->phone): ?><div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-phone red"></i> Téléphone:</span>
          <p class="widget-contact__text"> <?php echo e($consulatContact->phone); ?></p>
        </div>
        <?php endif; ?>
        <?php if($consulatContact->fax): ?>
        <div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-fax red"></i> Fax:</span>
          <p class="widget-contact__text"><?php echo e($consulatContact->fax); ?></p>
        </div>
        <?php endif; ?>
        <?php if($consulatContact->email): ?>
        <div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-envelope-o red"></i> Adresse email:</span>
          <p class="widget-contact__text"><a href="mailto:consular@madagaskar.us"><?php echo e($consulatContact->email); ?></a></p>
        </div>
        <?php endif; ?>
        <?php if($consulatContact->email2): ?>
        <div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-envelope-o red"></i> Adresse email 2:</span>
          <p class="widget-contact__text"><a href="#"> <?php echo e($consulatContact->email2); ?></a></p>
        </div>
        <?php endif; ?>
        <?php if($consulatContact->address): ?>
        <div class="widget-contact__item">
          <span class="widget-contact__title"><i class="fa fa-map-marker red"></i> Adresse:</span>
          <p class="widget-contact__text">
            <?php echo e($consulatContact->address); ?>

          </p>
        </div>
        <?php endif; ?>
        <?php endif; ?>

      </div>

    </div>

  <div class="col-lg-7 my-3 wow slideInRight">

    <div class="contact-gmap"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3008.0953586877195!2d28.996626015039336!3d41.06690817929489!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cab6ff5ae8e68d%3A0xdb925c03db5a6bb0!2sMadagascan%20Consulate!5e0!3m2!1sfr!2sus!4v1594484429491!5m2!1sfr!2sus" width="100%" height="500" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></div>

  </div>


</div>

</div>
</section>
<!--end contact-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/assets/js/count-down.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/index.blade.php ENDPATH**/ ?>