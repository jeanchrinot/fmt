<p class="text-muted"><strong>Titre:</strong> <?php echo e($details->name); ?></p>
<p class="text-muted"><strong>Slug:</strong> <?php echo e($details->slug); ?></p>
<p class="text-muted"><strong>Date:</strong> <?php echo e(formatDateTime($details->activity_date)); ?></p>
<p class="text-muted"><strong>Détails:</strong><br> <?php echo e($details->details); ?></p>
<div>
	<img src="<?php echo e(getImage($details->image)); ?>" style="max-width: 100%;">
</div><?php /**PATH E:\malagasy\laravel\resources\views/admin/components/activity.blade.php ENDPATH**/ ?>