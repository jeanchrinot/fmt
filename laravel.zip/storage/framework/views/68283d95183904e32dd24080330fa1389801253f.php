<?php $__env->startSection('title','Liste des galerie images'); ?>

<?php $__env->startSection('main'); ?>


<main class="col-sm-9 col-xs-12 content pt-3 pl-0" id="app">
	<h5 class="mb-0" ><strong>Images Galerie</strong></h5>
	<span class="text-secondary">Images Galerie <i class="fa fa-angle-right"></i> Toutes les images</span>

	<div class="row mt-3">
		<div class="col-sm-12">
			<!--Datatable-->
			<div class="mt-1 mb-3 p-3 button-container bg-white border shadow-sm">
				<div class="row">
					<div class="col-sm-6">
						<h6 class="mb-2">Liste des images</h6>
					</div>
					<div class="col-sm-6">
						<a class="btn btn-info text-white float-right my-3" href="<?php echo e(route('gallery.add')); ?>">Ajouter</a>
					</div>
					<div class="col-8" id="alert-area" style="margin-right: auto;margin-left: auto;">
						<?php if(\Session::has('success')): ?>
				              <div class="alert alert-success alert-dissmissible">
				              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				                      <?php echo \Session::get('success'); ?>

				                  
				              </div>
				          <?php endif; ?>
					</div>
				</div>
				
				<div class="table-responsive">
					<table id="example" class="table table-striped table-bordered text-center">
						<thead>
							<tr>
								<th>Image</th>
								<th>Titre</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php if(count($galleries)): ?>
							<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td class="align-middle">
									<img src="<?php echo e(getImage($gallery->image)); ?>" width="50" height="50" class=" rounded-circle" alt="Photo de profile">
								</td>
								<td class="align-middle"><?php echo e($gallery->title); ?></td>
								<td class="align-middle"><span class="badge badge-<?php echo e(($gallery->featured==true) ? 'success':'secondary'); ?>"><?php echo e(($gallery->featured==true) ? 'Actif':'Passif'); ?></span></td>
								<td class="d-flex justify-content-center">
									<item-details-button item-type="gallery" item-id="<?php echo e($gallery->id); ?>"></item-details-button>

									<div><a href="<?php echo e(route('gallery.edit',['id'=>$gallery->id])); ?>" class="action btn btn-success" style="margin-left: 4px;color:#fff;"><i class="fa fa-pencil"></i></a></div>
									<!--<button class="action btn btn-success"><i class="fa fa-pencil"></i></button>-->
									<delete-button item-type="gallery" item-id="<?php echo e($gallery->id); ?>"></delete-button>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
			<!--/Datatable-->

		</div>
	</div>

	<?php echo $__env->make('admin.includes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/admin/gallery.blade.php ENDPATH**/ ?>