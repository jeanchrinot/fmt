<?php $__env->startSection('title','Ajouter un mot'); ?>

<?php $__env->startSection('main'); ?>
<!--Content right-->
<main class="col-sm-9 mx-auto col-xs-12 content pt-3 pl-0">
  <h5 class="mb-0" ><strong>Vous pouvez ajouter  des mot d'étudiants</strong></h5>
  <span class="text-secondary">Dashboard <i class="fa fa-angle-right"></i>Mot d'étudiant</span>

  <?php 
    if(isset($word)){
      $update = 1;
    }
    else{
      $update = 0;
    }

    if(old('user')){
      $selected_user = old('user');
      $status = old('featured');
    }
    elseif(isset($word->user_id)){
      $selected_user = $word->user_id;
      $status = $word->featured;
    }
    else{
      $selected_user = '0';
      $status = 1;
    }

  ?>

  <!--modif membre bureau-->
  <div class="box-modif-student_word mt-3 mb-4 p-3 button-container bg-white border shadow-sm">
    <form class=" needs-validation p-2" novalidate id="new-member" action="<?php echo e(($update==1) ? route('page.item.update',['item'=>'student_words','id'=>$word->id]) : route('page.item.store',['item'=>'student_words'])); ?>" method="post">
      <?php echo e(csrf_field()); ?>


      <?php if($update==1): ?>
      <?php echo method_field('PATCH'); ?>
      <?php endif; ?>

          <?php if(\Session::has('success')): ?>
              <div class="alert alert-success">
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>

          <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                                <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
             <?php endif; ?>

      <div class="form-row">
        <div class="col-md-4 mb-2">
          <label for="user">Membre <span class="text-danger">*</span></label>
          <select class="form-control" id="user" name="user" required>
            <?php if($update==0): ?>
            <option value="">Membre</option>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($user->id); ?>" <?php echo e(($selected_user==$user->id) ? 'selected="selected"' : ''); ?>><?php echo e($user->surname); ?> <?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($update==1): ?>
             <option value="<?php echo e($users->id); ?>" <?php echo e(($selected_user==$users->id) ? 'selected="selected"' : ''); ?>><?php echo e($users->surname); ?> <?php echo e($users->name); ?></option>
            <?php endif; ?>
            
          </select>
          <div class="invalid-feedback">
            Veuillez entrer le nom
          </div>
        </div>
        <div class="col-md-4 mb-2">
          <label for="words">Mot d'étudiant <span class="text-danger">*</span></label>
          <textarea rows="5" type="text" class="form-control" name="words" id="words" required><?php echo e(old('words') ?? ($word->words ?? '')); ?></textarea>
          <div class="invalid-feedback">
            Veuillez entrer le mot d'étudiant
          </div>
        </div>
        <div class="col-md-4 mb-2">
          <label for="featured">Affiché ? <span class="text-danger">*</span></label>
          <select class="form-control" id="featured" name="featured" required>
            <option value="1" <?php echo e(($status==1) ? 'selected="selected"' : ''); ?>>Oui</option>
            <option value="0" <?php echo e(($status==0) ? 'selected="selected"' : ''); ?>>Non</option>
          </select>
          <div class="invalid-feedback">
            Veuillez choisir le statut
          </div>
        </div>
      </div>
  <div class="form-row">
   <button class="btn btn-primary my-2" type="submit">Enregistrer</button>
 </div>
</form>
</div><!--End modif student word-->

</main>
<!--Main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/admin/student_words_form.blade.php ENDPATH**/ ?>