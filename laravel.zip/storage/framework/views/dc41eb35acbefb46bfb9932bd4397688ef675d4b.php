<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('main'); ?>

<?php if($data): ?>
	<?php
	// Membre de bureau
	$office_members = $data['office_members'];
	$nb_om = count($office_members);
	// Membres
	$nb_m = count($data['users']);

	//Admin web

    $users = json_decode(json_encode($data['users']), true);
	$nb_admin = count(array_filter($users, function ($user) {
                        return ($user['type'] == 2);
                    }));

    $messages = $data['messages'];

	?>
<?php endif; ?>

<main class="col-sm-9 col-xs-12 content pt-3 pl-0" id="app">
	<h5 class="mb-3" ><strong>dashboard</strong></h5>


	<div class="mt-1 mb-3 button-container">
		<div class="row pl-0">
			<div class="col-lg-4 col-md-4 col-sm-6 col-12 mb-3">
				<div class="bg-white border shadow">
					<div class="media p-4">
						<div class="align-self-center mr-3 rounded-circle notify-icon bg-theme">
							<i class="fa fa-user"></i>
						</div>
						<div class="media-body pl-2">
							<h3 class="mt-0 mb-0"><strong><?php echo e($nb_m); ?></strong></h3>
							<p><small class="text-muted bc-description">nombre des membres</small></p>
						</div>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-4 col-sm-6 col-12 mb-3">
				<div class="bg-white border shadow">
					<div class="media p-4">
						<div class="align-self-center mr-3 rounded-circle notify-icon bg-danger">
							<i class="fa fa-envelope-open"></i>
						</div>
						<div class="media-body pl-2">
							<h3 class="mt-0 mb-0"><strong><?php echo e($nb_om); ?></strong></h3>
							<p><small class="text-muted bc-description">membres de bureau</small></p>
						</div>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-4 col-sm-6 col-12 mb-3">
				<div class="bg-theme border shadow">
					<div class="media p-4">
						<div class="align-self-center mr-3 rounded-circle notify-icon bg-white">
							<i class="fa fa-users text-theme"></i>
						</div>
						<div class="media-body pl-2">
							<h3 class="mt-0 mb-0"><strong><?php echo e($nb_admin); ?></strong></h3>
							<p><small class="bc-description text-white">admin web</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!--page Index-->
	<div class="mt-4 mb-4 p-3 bg-white border shadow-sm lh-sm">
		
		<div class="row">
			<!--Message-->
			<div class="table-responsive with-action" id="contact_message">
				<div class="pt-2">
					<h5 class="mb-4 text-center bc-header">Messages</h5>
				</div>
				<table class="table table-bordered table-striped mt-0 text-center">
					<thead>
						<tr>
							<th>Sujet</th>
							<th>Date</th>
							<th>Contenu</th>
							<th>Status</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php if(count($messages)): ?>
						<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="align-middle text-center"><?php echo e($message->subject); ?></td>
							<td  class="align-middle text-center"><?php echo e(date_format($message->created_at,"d/m/Y H:i")); ?></td>
							<th><?php echo e(substr($message->message,0,39)); ?><?php echo e(strlen($message->message)> 40 ? '...' : ''); ?></th>
							<td class="align-middle"><span class="badge <?php echo e(($message->viewed) ? 'badge-success':'badge-info'); ?>"><?php echo e(($message->viewed) ? 'lu':'nouveau'); ?></span></td>
							<td class=" align-middle text-center d-flex justify-content-center">
								<message-details-button msg-id="<?php echo e($message->id); ?>" viewed="<?php echo e($message->viewed); ?>"></message-details-button>

								<delete-button item-type="message" item-id="<?php echo e($message->id); ?>"></delete-button>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<tr>
							<td colspan="4">Aucun message réçu.</td>
						</tr>
						
						<?php endif; ?>
						
						
					</tbody>
				</table>
			</div>
			<!--End message-->
		</div>

		
		
	</div><!--End page Index-->

	<!-- Modal message -->
	<!-- <div id="messageDetails">
		<message-details></message-details>
	</div> -->
	
	<?php echo $__env->make('admin.includes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\malagasy\laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>