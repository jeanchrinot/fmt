<div>
	<p class="text-muted"><strong>Label:</strong> <?php echo e($details->name); ?></p>
	<p class="text-muted"><strong>Description:</strong> <?php echo e($details->details); ?></p>
</div>
<div class="img img--slider" style="position: relative;width: 100%;">
	<img src="<?php echo e(getImage($details->image)); ?>" style="max-width: 100%;">
</div><?php /**PATH E:\malagasy\laravel\resources\views/admin/components/slider.blade.php ENDPATH**/ ?>