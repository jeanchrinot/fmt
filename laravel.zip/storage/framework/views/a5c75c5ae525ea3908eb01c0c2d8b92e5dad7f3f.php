<p class="text-muted"><strong>Titre:</strong> <?php echo e($details->title); ?></p>
<p class="text-muted"><strong>Slug:</strong> <?php echo e($details->slug); ?></p>
<p class="text-muted"><strong>Détails:</strong><br> <?php echo e($details->details); ?></p>
<div>
	<img src="<?php echo e(getImage($details->image)); ?>" style="max-width: 100%;">
</div><?php /**PATH E:\malagasy\laravel\resources\views/admin/components/actu.blade.php ENDPATH**/ ?>